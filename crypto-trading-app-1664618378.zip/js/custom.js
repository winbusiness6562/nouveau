$(function(){
    
    setInterval(function() {
        //location.reload();
    }, 2000);
    
});